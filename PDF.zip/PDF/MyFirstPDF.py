import itertools
import json

from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas


class MyFirstPDF:

    def grouper(self, iterable, n):
        args = [iter(iterable)] * n
        return itertools.zip_longest(*args)

    def export_to_pdf(self, data):
        c = canvas.Canvas("grilla-alumnos.pdf", pagesize=LETTER)
        w, h = LETTER
        max_rows_per_page = 45
        x_offset = 50
        y_offset = 50
        padding = 15

        xlist = [x + x_offset for x in [0, 200, 250, 300, 350, 400, 480]]
        ylist = [h - y_offset - i*padding for i in range(max_rows_per_page + 1)]

        for rows in self.grouper(data, max_rows_per_page):
            rows = tuple(filter(bool, rows))
            c.grid(xlist, ylist[:len(rows) + 1])
            for y, row in zip(ylist[:-1], rows):
                for x, cell in zip(xlist, row):
                    c.drawString(x + 2, y - padding + 3, str(cell))
            c.showPage()

        c.save()

# 1. This will load the JSON file
with open("students.json", "r", encoding="utf-8") as f:
    students = json.load(f)

# 2. This will create the header row
data = [("NOMBRE", "EXAMEN", "NOTA", "GRADO", "GRUPO", "TURNO", "EMAIL")]

# 3. this will Loop through each student and add their data
for student in students:
    data.append((
        student["name"],
        student["exam"],
        student["note"],
        student["grade"],
        student["group"],
        student["shift"],
        student["email"]          
    ))

# 4. Generates the PDF with the students info of the whole class
my_pdf = MyFirstPDF()
my_pdf.export_to_pdf(data)
