from tkinter import *
from tkinter import messagebox
import json

class LoginApp:
    def __init__(self):
        self.window = Tk()
        self.window.title("Student Login")
        self.window.geometry("400x300")
        self.window.resizable(False, False)
        self.students = []
        self.load_students()
        self.create_widgets()

    def load_students(self):
        # Load students from JSON file
        try:
            with open("students.json", "r", encoding="utf-8") as file:
                data = json.load(file)
            
            # data could be a list or a dictionary
            if type(data) == list:
                self.students = data
            else:
                self.students = data.get("students", [])
                
        except FileNotFoundError:
            messagebox.showerror("Error", "students.json file not found!\nMake sure it's in the same folder as Main.py")
            self.students = []
        except json.JSONDecodeError as e:
            messagebox.showerror("Error", f"students.json is corrupted or invalid JSON:\n{e}")
            self.students = []
        except Exception as e:
            messagebox.showerror("Error", f"Could not load students.json:\n{e}")
            self.students = []

    def create_widgets(self):
        # Title label
        title = Label(self.window, text="Student Login", font=("Arial", 20, "bold"))
        title.pack(pady=20)
        
        # Username frame
        frame_user = Frame(self.window)
        frame_user.pack(pady=10)
        lbl_user = Label(frame_user, text="Username:", font=("Arial", 12), width=12, anchor="e")
        lbl_user.pack(side=LEFT)
        self.entry_user = Entry(frame_user, font=("Arial", 12), width=20)
        self.entry_user.pack(side=LEFT, padx=5)
        
        # Password frame
        frame_pass = Frame(self.window)
        frame_pass.pack(pady=10)
        lbl_pass = Label(frame_pass, text="Password:", font=("Arial", 12), width=12, anchor="e")
        lbl_pass.pack(side=LEFT)
        self.entry_pass = Entry(frame_pass, font=("Arial", 12), width=20, show="*")
        self.entry_pass.pack(side=LEFT, padx=5)
        
        # Login button
        btn_login = Button(self.window, text="Login", command=self.check_login,
                           bg="#4CAF50", fg="white", font=("Arial", 12, "bold"),
                           width=15, height=1)
        btn_login.pack(pady=20)
        
        # Bind Enter key to login
        self.window.bind('<Return>', lambda event: self.check_login())

    def check_login(self):
        # Get text from entries
        username = self.entry_user.get().strip()
        password = self.entry_pass.get().strip()
        
        # Check if empty
        if username == "" or password == "":
            messagebox.showwarning("Warning", "Please enter username and password")
            return
        
        # Look for student in list
        found = False
        for student in self.students:
            # Check different possible field names
            email = student.get("email", "")
            name = student.get("name", "")
            student_password = student.get("password", "")
            
            # Username could be email or name
            if username.lower() == email.lower() or username.lower() == name.lower():
                found = True
                # Check password
                if password == student_password:
                    self.show_user_data(student)
                else:
                    messagebox.showerror("Error", "Incorrect password")
                break
        
        if not found:
            messagebox.showerror("Not Found", "User does not exist. Please contact the Administrator.")

    def show_user_data(self, student):
        # Build message with user data
        name = student.get("name", "N/A")
        email = student.get("email", "N/A")
        password = student.get("password", "N/A")
        exam = student.get("exam", "N/A")
        grade = student.get("grade", "N/A")
        group = student.get("group", "N/A")
        shift = student.get("shift", "N/A")
        message = "Login Successful!\n\n"
        message = message + "Name: " + name + "\n"
        message = message + "Email: " + email + "\n"
        message = message + "Password: " + password + "\n"
        message = message + "Exam: " + str(exam) + "\n"
        message = message + "Grade: " + str(grade) + "\n"
        message = message + "Group: " + str(group) + "\n"
        message = message + "Shift: " + str(shift)
        messagebox.showinfo("User Data", message)
        
        # Clear entries after login
        self.entry_user.delete(0, END)
        self.entry_pass.delete(0, END)

    def run(self):
        self.window.mainloop()

# Start the app
app = LoginApp()
app.run()