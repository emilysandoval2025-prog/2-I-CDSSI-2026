import tkinter as tk

class ButtonTest:

    def button_clicked(self):
        print("Button clicked!")

    def draw_button(self):
        root = tk.Tk()
        root.title("Button Demo")
        # Creating a button with specified options
        button = tk.Button(root, 
                        text="Click Me", 
                        command=self.button_clicked,
                        activebackground="blue", 
                        activeforeground="white",
                        anchor="center",
                        bd=3,
                        bg="lightgray",
                        cursor="hand2",
                        disabledforeground="gray",
                        fg="black",
                        font=("Arial", 12),
                        height=2,
                        highlightbackground="black",
                        highlightcolor="green",
                        highlightthickness=2,
                        justify="center",
                        overrelief="raised",
                        padx=10,
                        pady=5,
                        width=15,
                        wraplength=100)

        button.pack(padx=20, pady=20)

        root.mainloop()

test = ButtonTest()
test.draw_button()