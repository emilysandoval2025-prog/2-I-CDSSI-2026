from tkinter import *
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
from Student import Student


class Main:
    def __init__(self):
        self.window = Tk()
        self.window.title("Student Manager")
        self.window.geometry("900x500")
        
        self.students = []
        
        self.create_table()
        self.create_buttons()
        
    def create_table(self):
        # Create frame for table
        frame = Frame(self.window)
        frame.pack(pady=10, padx=10)
        
        # Create Treeview
        columns = ("Middle Last Name", "First Name", "Last Name", "Email", "Exam", "Grade", "Group", "Shift")
        self.table = ttk.Treeview(frame, columns=columns, show="headings", height=15)
        
        # Set column headings
        self.table.heading("Middle Last Name", text="Middle Last Name")
        self.table.heading("First Name", text="First Name")
        self.table.heading("Last Name", text="Last Name")
        self.table.heading("Email", text="Email")
        self.table.heading("Exam", text="Exam")
        self.table.heading("Grade", text="Grade")
        self.table.heading("Group", text="Group")
        self.table.heading("Shift", text="Shift")
        
        # Column widths
        self.table.column("Middle Last Name", width=120)
        self.table.column("First Name", width=120)
        self.table.column("Last Name", width=100)
        self.table.column("Email", width=200)
        self.table.column("Exam", width=60)
        self.table.column("Grade", width=50)
        self.table.column("Group", width=50)
        self.table.column("Shift", width=80)
        
        # Scrollbar
        scroll = Scrollbar(frame, command=self.table.yview)
        self.table.config(yscrollcommand=scroll.set)
        
        self.table.pack(side=LEFT)
        scroll.pack(side=RIGHT, fill=Y)
        
    def create_buttons(self):
        # Frame for buttons
        button_frame = Frame(self.window)
        button_frame.pack(pady=10)
        
        # Open file button
        btn_open = Button(button_frame, text="Open File", command=self.open_file, 
                          bg="lightblue", width=15)
        btn_open.pack(side=LEFT, padx=5)
        
        # Sort button
        btn_sort = Button(button_frame, text="Sort by Middle Last Name", command=self.sort_students,
                          bg="lightgreen", width=20)
        btn_sort.pack(side=LEFT, padx=5)
        
        # Clear button
        btn_clear = Button(button_frame, text="Clear", command=self.clear_table,
                           bg="lightyellow", width=15)
        btn_clear.pack(side=LEFT, padx=5)
        
    def open_file(self):
        # Open file dialog
        file = filedialog.askopenfilename(
            title="Select file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if file:
            self.load_students(file)
            
    def split_name(self, full_name):
        # Split full name into parts
        words = full_name.split()
        
        if len(words) >= 4:
            # Second to last is the middle last name
            middle_last_name = words[-2]
            # Last is the last name
            last_name = words[-1]
            # Everything else is the first name
            first_name = ""
            for i in range(len(words) - 2):
                first_name = first_name + words[i] + " "
            first_name = first_name.strip()
            
        elif len(words) == 3:
            # 3 words: first name + middle last name + last name
            first_name = words[0]
            middle_last_name = words[1]
            last_name = words[2]
            
        elif len(words) == 2:
            # Only first name and one last name
            first_name = words[0]
            middle_last_name = words[1]
            last_name = ""
            
        else:
            # Only one word
            first_name = words[0]
            middle_last_name = ""
            last_name = ""
            
        return first_name, middle_last_name, last_name
            
    def load_students(self, path):
        self.students = []
        
        try:
            file = open(path, "r")
            lines = file.readlines()
            file.close()
            
            # Skip first line (header)
            for i in range(1, len(lines)):
                line = lines[i].strip()
                
                if line == "":
                    continue
                    
                # Split by |
                parts = line.split("|")
                
                # Clean spaces
                for j in range(len(parts)):
                    parts[j] = parts[j].strip()
                
                # Get data
                full_name = parts[0]
                email = parts[1] if len(parts) > 1 else ""
                exam = parts[2] if len(parts) > 2 else "0"
                
                # Fill missing data with defaults
                # Grade = 2, Group = I, Shift = afternoon
                grade = parts[3] if len(parts) > 3 and parts[3].strip() != "" else "2"
                group = parts[4] if len(parts) > 4 and parts[4].strip() != "" else "I"
                shift = parts[5] if len(parts) > 5 and parts[5].strip() != "" else "afternoon"
                
                # Split name and last names
                first_name, middle_last_name, last_name = self.split_name(full_name)
                
                # Create Student object
                student = Student(full_name, email, exam, "0", grade, group, shift)
                # Save separated last names for sorting
                student.middle_last_name = middle_last_name
                student.last_name = last_name
                student.first_name_only = first_name
                self.students.append(student)
                
            self.show_students()
            messagebox.showinfo("Done", "Loaded " + str(len(self.students)) + " students")
            
        except:
            messagebox.showerror("Error", "Could not open file")
            
    def show_students(self):
        # Clear table
        for item in self.table.get_children():
            self.table.delete(item)
            
        # Show each student
        for student in self.students:
            # Insert into table
            self.table.insert("", END, values=(student.middle_last_name, 
                                               student.first_name_only,
                                               student.last_name, 
                                               student.email, 
                                               student.exam, 
                                               student.grade, 
                                               student.group, 
                                               student.shift))
                                               
    def sort_students(self):
        # Sort by middle last name (bubble sort simple)
        n = len(self.students)
        for i in range(n):
            for j in range(0, n - i - 1):
                # Get middle last names
                name1 = self.students[j].middle_last_name.lower()
                name2 = self.students[j + 1].middle_last_name.lower()
                
                if name1 > name2:
                    # Swap
                    temp = self.students[j]
                    self.students[j] = self.students[j + 1]
                    self.students[j + 1] = temp
                    
        self.show_students()
        messagebox.showinfo("Done", "Students sorted by middle last name")
        
    def clear_table(self):
        self.students = []
        for item in self.table.get_children():
            self.table.delete(item)
            
    def run(self):
        self.window.mainloop()


# Run program
app = Main()
app.run()