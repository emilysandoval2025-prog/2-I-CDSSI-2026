# "Emily Sandoval Madero 2I"
import json
import xml.etree.ElementTree as ET
from FileManager import FileManager
from Student import Student


class MainProgram:
    def obj_dict(self, obj):
        return obj.__dict__

    def format_name(self, name_to_order):
        name = name_to_order.strip().title()
        parts = name.split()
        
        if len(parts) == 3:
            return f"{parts[2]} {parts[0]} {parts[1]}"
        elif len(parts) >= 4:
            last_names = " ".join(parts[2:])
            first_names = " ".join(parts[:2])
            return f"{last_names} {first_names}"
        else:
            return name

    def get_last_name(self, formatted_name):
        return formatted_name.split()[0]

    def create_dataset(self, path, mode):
        test = FileManager()
        f_lines = test.get_file_lines(path, mode)
        students = []
        i = 0
        for tmpStudent in f_lines:
            if i > 0:  # Skip header line
                student = tmpStudent.split("|")
                if len(student) >= 5:
                    name_raw = student[0].strip()
                    email = student[1].strip()
                    exam = student[2].strip() if student[2].strip() != "" else "0"
                    note = student[3].strip() if student[3].strip() != "" else "0"
                    grade = student[4].strip() if len(student) > 4 and student[4].strip() != "" else "2"
                    group = student[5].strip() if len(student) > 5 and student[5].strip() != "" else "I"
                    shift = student[6].strip() if len(student) > 6 and student[6].strip() != "" else "V"

                    student_obj = Student(
                        self.format_name(name_raw),
                        email,
                        exam,
                        note,
                        grade,
                        group,
                        shift
                    )
                    students.append(student_obj)
            i = i + 1
        
        return sorted(students, key=lambda p: self.get_last_name(p.name))

    def create_csv(self, list_students):
        text = "name,email,exam,note,grade,group,shift\n"
        fm = FileManager()
        for student in list_students:
            text = text + f"{student.name},{student.email},{student.exam},{student.note},{student.grade},{student.group},{student.shift}\n"
        fm.write_text("students.csv", text)
        print("students.csv created successfully!")

    def create_txt(self, list_students):
        text = ""
        fm = FileManager()
        for student in list_students:
            text = text + f"{student.name} | Email: {student.email} | Exam: {student.exam} | Note: {student.note} | Grade: {student.grade} | Group: {student.group} | Shift: {student.shift}\n"
        fm.write_text("students.txt", text)
        print("students.txt created successfully!")

    def object_to_json(self, obj_list):
        students_list = []
        for student in obj_list:
            students_list.append({
                "name": student.name,
                "email": student.email,
                "exam": student.exam,
                "note": student.note,
                "grade": student.grade,
                "group": student.group,
                "shift": student.shift
            })
        json_data = {"students": students_list}
        json_pretty = json.dumps(json_data, indent=4)
        
        fm = FileManager()
        fm.write_text("students.json", json_pretty)
        print("students.json created successfully!")

    def object_to_xml(self, obj_list):
        root = ET.Element("students")
        
        for student in obj_list:
            student_elem = ET.SubElement(root, "student")
            
            ET.SubElement(student_elem, "name").text = str(student.name)
            ET.SubElement(student_elem, "email").text = str(student.email)
            ET.SubElement(student_elem, "exam").text = str(student.exam)
            ET.SubElement(student_elem, "note").text = str(student.note)
            ET.SubElement(student_elem, "grade").text = str(student.grade)
            ET.SubElement(student_elem, "group").text = str(student.group)
            ET.SubElement(student_elem, "shift").text = str(student.shift)
        
        import xml.dom.minidom
        xml_str = ET.tostring(root, encoding='unicode')
        dom = xml.dom.minidom.parseString(xml_str)
        pretty_xml = dom.toprettyxml(indent="    ")
        
        fm = FileManager()
        fm.write_text("students.xml", pretty_xml)
        print("students.xml created successfully!")

    def object_to_yaml(self, obj_list):
        text = "students:\n"
        for i, student in enumerate(obj_list):
            text = text + f"  - id: {i + 1}\n"
            text = text + f"    name: {student.name}\n"
            text = text + f"    email: {student.email}\n"
            text = text + f"    exam: {student.exam}\n"
            text = text + f"    note: {student.note}\n"
            text = text + f"    grade: {student.grade}\n"
            text = text + f"    group: {student.group}\n"
            text = text + f"    shift: {student.shift}\n"
        
        fm = FileManager()
        fm.write_text("students.yaml", text)
        print("students.yaml created successfully!")

    def example(self):
        test = FileManager()
        test.read_entire_file('example.txt', 'r')
        test.get_file_lines('example.txt', 'r')
        test.read_line_by_line('example.txt', 'r')

    def writting_example(self):
        test = FileManager()
        test.write_text('example2.txt', "test text")


if __name__ == "__main__":
    main = MainProgram()
    
    print("=== Testing FileManager ===")
    main.example()
    main.writting_example()
    
    print("\n=== Creating Dataset from 2-1 mit.txt ===")
    user_list = main.create_dataset('/home/bobalatte04/Files/2I mit.txt', 'r')
    
    print(f"Total students processed: {len(user_list)}")
    
    print("\n=== Generating Output Files ===")
    main.create_csv(user_list)
    main.create_txt(user_list)
    main.object_to_json(user_list)
    main.object_to_xml(user_list)
    main.object_to_yaml(user_list)
    
    print("\n=== All files created successfully! ===")
    